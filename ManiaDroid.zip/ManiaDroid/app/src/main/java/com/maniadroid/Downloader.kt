package com.maniadroid

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import android.widget.ImageView
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

object Net {
    fun open(url: String, accept: String? = null): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 30000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "ManiaDroid/1.0 (Android)")
        if (accept != null) c.setRequestProperty("Accept", accept)
        return c
    }
}

object Img {
    private val cache = LruCache<String, Bitmap>(80)
    private val pool = Executors.newFixedThreadPool(3)

    fun load(url: String, iv: ImageView) {
        iv.tag = url
        val hit = cache.get(url)
        if (hit != null) {
            iv.setImageBitmap(hit)
            return
        }
        iv.setImageDrawable(null)
        pool.execute {
            try {
                val c = Net.open(url)
                val bmp = c.inputStream.use { BitmapFactory.decodeStream(it) }
                if (bmp != null) {
                    cache.put(url, bmp)
                    iv.post { if (iv.tag == url) iv.setImageBitmap(bmp) }
                }
            } catch (e: Exception) {
            }
        }
    }
}

object Downloader {
    val mirrors = arrayOf("Nerinyan", "Catboy")

    class Remote(
        val id: Int,
        val title: String,
        val artist: String,
        val creator: String,
        val status: String,
        val info: String
    )

    /** Cari chart mania (mode=3) di mirror. Satu-satunya fungsi online selain download(). */
    fun search(q: String, page: Int): List<Remote> {
        val enc = URLEncoder.encode(q, "UTF-8")
        val url = if (Settings.mirror == 0)
            "https://api.nerinyan.moe/search?q=$enc&m=3&ps=20&p=$page"
        else
            "https://catboy.best/api/v2/search?q=$enc&query=$enc&mode=3&limit=20&offset=${page * 20}"
        val c = Net.open(url, "application/json")
        try {
            if (c.responseCode != 200) throw IOException("HTTP ${c.responseCode}")
            val body = c.inputStream.bufferedReader().use { it.readText() }.trim()
            val arr: JSONArray = if (body.startsWith("[")) JSONArray(body)
            else JSONObject(body).optJSONArray("beatmapsets") ?: JSONArray()
            val out = ArrayList<Remote>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val id = o.optInt("id")
                if (id == 0) continue
                val bms = o.optJSONArray("beatmaps")
                val ks = sortedSetOf<Int>()
                if (bms != null) {
                    for (j in 0 until bms.length()) {
                        val b = bms.getJSONObject(j)
                        if (b.optInt("mode_int", 3) == 3) {
                            val cs = b.optDouble("cs", 0.0).toInt()
                            if (cs > 0) ks.add(cs)
                        }
                    }
                }
                val info = (if (ks.isEmpty()) "" else ks.joinToString(", ") { "${it}K" } + " · ") +
                        "oleh ${o.optString("creator")}"
                out.add(Remote(id, o.optString("title"), o.optString("artist"), o.optString("creator"), o.optString("status"), info))
            }
            return out
        } finally {
            c.disconnect()
        }
    }

    /** Unduh + impor satu beatmapset. Return jumlah chart mania yang terpasang. */
    fun download(c: Context, id: Int, progress: (String) -> Unit): Int {
        val noVideo = !Settings.dlVideo
        val url = if (Settings.mirror == 0)
            "https://api.nerinyan.moe/d/$id" + (if (noVideo) "?nv=1" else "")
        else
            "https://catboy.best/d/$id" + (if (noVideo) "n" else "")
        val conn = Net.open(url, "application/x-osu-beatmap-archive, application/octet-stream, */*")
        val tmp = File(c.cacheDir, "dl_$id.osz")
        try {
            if (conn.responseCode != 200) throw IOException("HTTP ${conn.responseCode}")
            val total = conn.contentLengthLong
            conn.inputStream.use { ins ->
                FileOutputStream(tmp).use { out ->
                    val buf = ByteArray(32768)
                    var got = 0L
                    var last = -1
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        got += n
                        val step = if (total > 0) (got * 100 / total).toInt()
                        else (got / (1024 * 512)).toInt()
                        if (step != last) {
                            last = step
                            progress(if (total > 0) "$step%" else String.format("%.1f MB", got / 1048576.0))
                        }
                    }
                }
            }
            progress("Mengimpor…")
            val count = Library.importOsz(c, "dl_$id") { FileInputStream(tmp) }
            if (count <= 0) throw IOException("Bukan chart mania / file rusak")
            return count
        } finally {
            tmp.delete()
            conn.disconnect()
        }
    }
}
