package com.maniadroid

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.widget.Button
import android.widget.FrameLayout
import android.widget.TextView

object Ui {
    const val BG = 0xFF11111B.toInt()
    const val CARD = 0xFF1D1D2B.toInt()
    const val ACCENT = 0xFFFF5FA2.toInt()
    const val TEXT = 0xFFEDEDF5.toInt()
    const val SUB = 0xFF9A9AB0.toInt()

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density + 0.5f).toInt()

    fun rounded(color: Int, radius: Float): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(color)
        d.cornerRadius = radius
        return d
    }

    fun text(c: Context, s: String, sp: Float = 15f, color: Int = TEXT, bold: Boolean = false): TextView {
        val t = TextView(c)
        t.text = s
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        t.setTextColor(color)
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        return t
    }

    fun button(c: Context, s: String, onClick: () -> Unit): Button {
        val b = Button(c)
        b.text = s
        b.isAllCaps = false
        b.setTextColor(Color.WHITE)
        b.background = rounded(ACCENT, dp(c, 10).toFloat())
        b.setOnClickListener { onClick() }
        return b
    }

    fun matchParams(): FrameLayout.LayoutParams = FrameLayout.LayoutParams(-1, -1)
}
