package com.maniadroid

import android.app.Activity
import android.os.Bundle
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import java.io.File

class DownloadActivity : Activity() {
    private val items = ArrayList<Downloader.Remote>()
    private val state = HashMap<Int, String>()
    private lateinit var adapter: BaseAdapter
    private lateinit var status: TextView
    private lateinit var input: EditText
    private lateinit var moreBtn: Button
    private var page = 0
    private var query = ""
    private var loading = false
    private var more = true

    private fun dp(v: Int) = Ui.dp(this, v)

    private inner class Holder {
        val img = ImageView(this@DownloadActivity)
        val title = Ui.text(this@DownloadActivity, "", 15f, Ui.TEXT, true)
        val sub = Ui.text(this@DownloadActivity, "", 12f, Ui.SUB)
        val btn = Button(this@DownloadActivity)
        val root = LinearLayout(this@DownloadActivity)

        init {
            img.scaleType = ImageView.ScaleType.CENTER_CROP
            img.setBackgroundColor(Ui.BG)
            title.maxLines = 1
            title.ellipsize = TextUtils.TruncateAt.END
            sub.maxLines = 2
            sub.ellipsize = TextUtils.TruncateAt.END
            btn.isAllCaps = false
            btn.textSize = 12f
            btn.setTextColor(Color.WHITE)
            btn.background = Ui.rounded(Ui.ACCENT, dp(10).toFloat())
            btn.isFocusable = false
            val texts = LinearLayout(this@DownloadActivity)
            texts.orientation = LinearLayout.VERTICAL
            texts.addView(title)
            texts.addView(sub)
            root.orientation = LinearLayout.HORIZONTAL
            root.gravity = Gravity.CENTER_VERTICAL
            root.setPadding(dp(8), dp(8), dp(8), dp(8))
            root.background = Ui.rounded(Ui.CARD, dp(12).toFloat())
            root.addView(img, LinearLayout.LayoutParams(dp(64), dp(64)))
            val tp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            tp.leftMargin = dp(10)
            tp.rightMargin = dp(8)
            root.addView(texts, tp)
            root.addView(btn, LinearLayout.LayoutParams(dp(92), dp(42)))
            root.tag = this
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Settings.init(this)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.BG)
        root.setPadding(dp(12), dp(12), dp(12), dp(8))

        root.addView(Ui.text(this, "Unduh Chart (mania)", 22f, Ui.TEXT, true))
        root.addView(
            Ui.text(this, "Mirror: ${Downloader.mirrors[Settings.mirror]} · ganti di Pengaturan. Internet hanya dipakai di layar ini.", 11f, Ui.SUB)
        )

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        input = EditText(this)
        input.hint = "Judul / artis / mapper, atau ID beatmapset"
        input.setHintTextColor(Ui.SUB)
        input.setTextColor(Ui.TEXT)
        input.inputType = InputType.TYPE_CLASS_TEXT
        input.imeOptions = EditorInfo.IME_ACTION_SEARCH
        input.setSingleLine(true)
        input.setOnEditorActionListener { _, _, _ ->
            load(true)
            true
        }
        row.addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(Ui.button(this, "Cari") { load(true) })
        root.addView(row)

        status = Ui.text(this, "", 13f, Ui.SUB)
        status.setPadding(0, dp(6), 0, dp(6))
        root.addView(status)

        val list = ListView(this)
        list.divider = ColorDrawable(Color.TRANSPARENT)
        list.dividerHeight = dp(8)
        moreBtn = Ui.button(this, "Muat lebih banyak") { load(false) }
        moreBtn.visibility = View.GONE
        list.addFooterView(moreBtn)
        adapter = object : BaseAdapter() {
            override fun getCount() = items.size
            override fun getItem(position: Int): Any = items[position]
            override fun getItemId(position: Int) = items[position].id.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val h = (convertView?.tag as? Holder) ?: Holder()
                val r = items[position]
                h.title.text = if (r.artist.isEmpty()) r.title else "${r.artist} - ${r.title}"
                h.sub.text = r.info
                Img.load("https://assets.ppy.sh/beatmaps/${r.id}/covers/list.jpg", h.img)
                val installed = File(Library.songsDir(this@DownloadActivity), "dl_${r.id}").exists()
                val s = state[r.id]
                h.btn.text = s ?: if (installed) "Terpasang ✓" else "Unduh"
                h.btn.isEnabled = s == null
                h.btn.setOnClickListener { startDownload(r) }
                return h.root
            }
        }
        list.adapter = adapter
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        load(true)
    }

    private fun load(reset: Boolean) {
        if (loading) return
        if (reset) {
            page = 0
            items.clear()
            more = true
            query = input.text.toString().trim()
            adapter.notifyDataSetChanged()
            val id = query.toIntOrNull()
            if (id != null && id > 0) { // unduh langsung lewat ID beatmapset
                items.add(Downloader.Remote(id, "Beatmapset #$id", "", "", "", "Unduh langsung via ID"))
                adapter.notifyDataSetChanged()
                status.text = ""
                moreBtn.visibility = View.GONE
                return
            }
        }
        loading = true
        status.text = "Memuat…"
        val q = query
        val pg = page
        Thread {
            try {
                val r = Downloader.search(q, pg)
                runOnUiThread {
                    items.addAll(r)
                    page++
                    more = r.size >= 20
                    loading = false
                    status.text = if (items.isEmpty()) "Tidak ada hasil" else ""
                    moreBtn.visibility = if (more && items.isNotEmpty()) View.VISIBLE else View.GONE
                    adapter.notifyDataSetChanged()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    loading = false
                    status.text = "Gagal memuat (${e.message}). Cek internet, ganti mirror di Pengaturan, " +
                            "atau ketik ID beatmapset (angka) lalu Cari untuk unduh langsung."
                }
            }
        }.start()
    }

    private fun startDownload(r: Downloader.Remote) {
        if (state.containsKey(r.id)) return
        state[r.id] = "0%"
        adapter.notifyDataSetChanged()
        Thread {
            try {
                val n = Downloader.download(this, r.id) { txt ->
                    runOnUiThread {
                        state[r.id] = txt
                        adapter.notifyDataSetChanged()
                    }
                }
                runOnUiThread {
                    state.remove(r.id)
                    Toast.makeText(this, "Terpasang: $n chart mania", Toast.LENGTH_SHORT).show()
                    adapter.notifyDataSetChanged()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    state.remove(r.id)
                    Toast.makeText(this, "Gagal unduh: ${e.message}", Toast.LENGTH_LONG).show()
                    adapter.notifyDataSetChanged()
                }
            }
        }.start()
    }
}
